/**
 * Created by Dell on 15-08-2016.
 */

app.constant('API', {
    "ANR": "http://localhost:9000/",
    "SMSAPI": "http://login.bulksmsgateway.in/sendmessage.php?user=SANTH&password=54321"
});
